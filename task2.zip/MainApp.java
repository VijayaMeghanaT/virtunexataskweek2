import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class MainApp extends JFrame {
    private JTextField inputField;
    private JTextArea resultArea;
    private ArrayList<String> history;

    public MainApp() {
        super("ASCII Value Finder");
        history = new ArrayList<>();
        setupUI();
    }

    private void setupUI() {
        setSize(400, 250);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        inputField = new JTextField(5);
        JButton convertButton = new JButton("Get ASCII Value");
        resultArea = new JTextArea(5, 30);
        resultArea.setEditable(false);

        convertButton.addActionListener(e -> convertToASCII());

        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        panel.add(new JLabel("Enter a character:"));
        panel.add(inputField);
        panel.add(convertButton);

        add(panel, BorderLayout.NORTH);
        add(new JScrollPane(resultArea), BorderLayout.CENTER);
    }

    private void convertToASCII() {
        String input = inputField.getText();

        if (input.length() != 1) {
            JOptionPane.showMessageDialog(this, "Please enter exactly one character.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return;
        }

        char character = input.charAt(0);
        int ascii = (int) character;

        String result = "Character: '" + character + "' → ASCII: " + ascii;
        resultArea.append(result + "\n");
        history.add(result);
        inputField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainApp().setVisible(true));
    }
}
